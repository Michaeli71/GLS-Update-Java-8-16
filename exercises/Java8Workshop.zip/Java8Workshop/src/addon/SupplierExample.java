package addon;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class SupplierExample
{

    public static void main(String[] args)
    {
        Supplier<String> strProvider = () -> complicatedCalculateResult();        
        Predicate<String> isEmpty = String::isEmpty;
        
        Function<String, Long> processData1 = str -> (long) str.length();

        supplyAsync(strProvider);
        
        List<String> names = Arrays.asList("Tim", "Tom", "Peter");
        Consumer<String> action = System.out::println;
        names.forEach(action);      
    }
    
    private static String complicatedCalculateResult()
    {
        return "MEIN RESULTAT";
    }

    private static String supplyAsync(Supplier<String> supplier)
    {
        return supplier.get();        
    }
}
