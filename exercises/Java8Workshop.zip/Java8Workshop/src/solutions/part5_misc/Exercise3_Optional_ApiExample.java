package solutions.part5_misc;

import java.util.Optional;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise3_Optional_ApiExample
{
    public static void main(final String[] args)
    {
        // Hier noch un elegant gelöst, wir lernen später ifPresentorElse() kennen
        final Optional<Person> optPerson1 = findPersonByName("unknown");
        if (optPerson1.isPresent())
        {
            processPerson(optPerson1.get());
        }
        else
        {
            System.out.println("No person found!");
        }
        
        final Optional<Person> optPerson2 = findPersonByName("Micha");
        if (optPerson2.isPresent())
        {
            processPerson(optPerson2.get());
        }
        else
        {
            System.out.println("No person found!");
        }
    }

    private static Optional<Person> findPersonByName(final String name)
    {
        if (name.equals("Micha"))
            return Optional.of(new Person("Micha", 46));

        return Optional.ofNullable(null);
    }

    private static void processPerson(final Person person)
    {
        System.out.println(person);
    }
}
