package solutions.part5_misc;

import java.util.concurrent.CompletableFuture;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2017 by Michael Inden
 */
public class CompletableFutureAndExceptions
{
    public static void main(final String[] args)
    {
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> "Start");
        future = future.thenApply(str -> {
            System.out.println("Stage 1: " + str);
            return "A";
        });
        future = future.thenApply(str -> {
            System.out.println("Stage 2: " + str);
            if (true)
                throw new RuntimeException();
            return "B";
        });
        future = future.thenApply(str -> {
            System.out.println("Stage 3: " + str);
            return "C";
        });
        future.exceptionally(e -> {
            System.out.println("Exceptionally");
            return null;
        });
    }
}
