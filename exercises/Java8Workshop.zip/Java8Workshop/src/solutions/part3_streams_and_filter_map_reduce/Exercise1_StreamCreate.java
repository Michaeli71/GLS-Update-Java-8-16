package solutions.part3_streams_and_filter_map_reduce;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise1_StreamCreate 
{
	public static void main(String[] args) 
	{
		final String[] namesArray = {"Tim", "Tom", "Andy", "Mike", "Merten"};
		final List<String> names = Arrays.asList(namesArray);

		// b)
		final Stream<String> streamFromArray = Arrays.stream(namesArray);
		final Stream<String> streamFromList = names.stream();
		final Stream<String> streamFromValues = Stream.of("Tim", "Tom", "Andy");
		
		// c)
		final Stream<String> filtered = streamFromList.filter(str -> str.startsWith("T"));
		final Stream<String> mapped = filtered.map(str -> str.toUpperCase());
		
		// d)
		mapped.forEach(System.out::println);
	}
}
