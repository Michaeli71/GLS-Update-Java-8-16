package solutions.part3_streams_and_filter_map_reduce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise2_Joining {

	public static void main(String[] args) 
	{
		final String[] namesArray = {"Tim", "Tom", "Andy", "Mike", "Merten"};
		final List<String> names = Arrays.asList(namesArray);

		names.stream().filter(str -> str.length() >= 4).forEach(str -> System.out.print(str + ", "));
		System.out.println();
		
		// Collectors.joining
		final String joined = names.stream().collect(Collectors.joining(", "));
		System.out.println(joined);
		
		// Variante
		List<String> list = new ArrayList<>(Arrays.asList(namesArray));

		// expression
		boolean anyMatch1 = list.stream().anyMatch(s -> s.contains("M"));
		// statement
		boolean anyMatch2 = list.stream().anyMatch(s -> {
		  return s.contains("M");
		});
	      // statement
        boolean anyMatch3 = list.stream().anyMatch(s -> {
          boolean containsM = s.contains("M");
          return containsM;
        });
		System.out.println("" + anyMatch1 + anyMatch2+anyMatch3);
	}
}
