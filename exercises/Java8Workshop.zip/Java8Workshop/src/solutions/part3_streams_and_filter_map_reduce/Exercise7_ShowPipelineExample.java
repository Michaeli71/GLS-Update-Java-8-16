package solutions.part3_streams_and_filter_map_reduce;

import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise7_ShowPipelineExample
{
    public static void main(String[] args)
    {
        Stream.of("Andi", "Barbara", "Tom", "Carsten", "Mike", "Marius", "Micha", "Tim")
                        .peek(str -> System.out.println("taking element: " + str))        
                        .filter(str -> str.length() > 4)
                        .peek(str -> System.out.println("after filter > 4: " + str))        
                        .map(str -> str.toUpperCase())      
                        .peek(str -> System.out.println("after map: " + str))   
                        .filter(str -> str.startsWith("M"))
                        .peek(str -> System.out.println("after filter 'M': " + str))        
                        .forEach(name -> System.out.println("forEach: " + name));
    }
}