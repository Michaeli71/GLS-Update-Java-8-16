package solutions.part2_bulk_operations;

import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise3_Iteration {

	public static void main(String[] args) {

		final List<String> names = Arrays.asList("Tim", "Peter", "Mike");
		
		// External Iteration
		for (final String name : names)
		{
			System.out.println(name);
		}
			
		// Internal Iteration
		names.forEach(System.out::println);
	}
}
