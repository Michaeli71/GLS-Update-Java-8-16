package solutions.part4_date_and_time;

import java.time.ZoneId;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise5_ZoneIds 
{
	public static void main(final String[] args) 
	{
		final Set<String> availableZoneIds = ZoneId.getAvailableZoneIds();
		
		final Predicate<String> europeOrAmerica = zoneId -> zoneId.contains("Europe/S") ||
					                                        zoneId.contains("America/L");
		
		final Stream<String> filteredZoneIds = availableZoneIds.stream().filter(europeOrAmerica);
		filteredZoneIds.sorted().forEach(System.out::println);
	}
}
