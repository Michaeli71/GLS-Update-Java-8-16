package solutions.part4_date_and_time;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Java 8 Hands on Workshops
 * 
 * @author Michael Inden
 *
 * Copyright 2015 by Michael Inden
 */
public class Exercise8_FaultTolerantParsingExample 
{
public static void main(final String[] args) 
{
	final List<String> exampleDates = Arrays.asList("07.02.71", "07.02.1971", "02/07/1971", "1971-02-07");
	
	for (final String dateAsString : exampleDates)
	{
		final LocalDate parsedLocalDate = faulttolerantparse(dateAsString);
		System.out.println("Parsed '" + dateAsString + "' into: " + parsedLocalDate);
	}
}

private static LocalDate faulttolerantparse(final String dateAsString) {
	final List<String> patterns = Arrays.asList("dd.MM.yy", "dd.MM.yyyy", "MM/dd/yyyy", "yyyy-MM-dd");
	
	for (final String pattern : patterns)
	{
		try
		{
			final DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
			return LocalDate.parse(dateAsString, formatter);
		}
		catch (DateTimeParseException dtpe)
		{
			// try next
		}
	}
	throw new DateTimeParseException("unsupported date format", dateAsString, 0);
}
}
