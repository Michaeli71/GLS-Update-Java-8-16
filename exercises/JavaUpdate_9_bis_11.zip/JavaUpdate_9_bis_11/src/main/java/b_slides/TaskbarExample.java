package b_slides;

import java.awt.Image;
import java.awt.Taskbar;
import java.awt.Taskbar.Feature;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.function.Consumer;

import javax.imageio.ImageIO;

/**
 * Beispielprogramm für das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017 by Michael Inden 
 */
public class TaskbarExample
{
    public static void main(final String[] args) throws Exception
    {
        if (Taskbar.isTaskbarSupported())
        {
            final Taskbar taskbar = Taskbar.getTaskbar();
            showProvidedFeatures(taskbar);

            performSomeTaskbarChanges(taskbar);
        }
        else
        {
            System.out.println("Taskbar is not supported on your platform. Unlucky you :(");
        }
    }

    private static void showProvidedFeatures(Taskbar taskbar)
    {
        System.out.println("Taskbar is supported and provides the following features:");

        final Consumer<Feature> checkFeatureSupport = feature -> System.out
                        .printf("Feature %s " + "is supported: %s%n", feature, taskbar.isSupported(feature));

        Arrays.stream(Feature.values()).forEach(checkFeatureSupport);
    }

    private static void performSomeTaskbarChanges(Taskbar taskbar) throws IOException, InterruptedException
    {
        setImage(taskbar);

        setBadge(taskbar, "1");

        requestUserAttention(taskbar, false); // springt einmal

        setBadge(taskbar, "2");

        setBadge(taskbar, "progress");

        requestUserAttention(taskbar, true); // springt fortwährend              

        performProgressInteraction(taskbar);
    }

    private static void setImage(final Taskbar taskbar) throws IOException, InterruptedException
    {
        if (taskbar.isSupported(Feature.ICON_IMAGE))
        {
            final InputStream imageInputStream = TaskbarExample.class.getResourceAsStream("prog.png");
            final Image image = ImageIO.read(imageInputStream);
            taskbar.setIconImage(image);
            Thread.sleep(2500);
        }
    }

    private static void setBadge(final Taskbar taskbar, final String text) throws InterruptedException
    {
        if (taskbar.isSupported(Feature.ICON_BADGE_TEXT))
        {
            taskbar.setIconBadge(text);
            Thread.sleep(1000);
        }
    }

    private static void requestUserAttention(final Taskbar taskbar, final boolean critical) throws InterruptedException
    {
        if (taskbar.isSupported(Feature.USER_ATTENTION))
        {
            taskbar.requestUserAttention(true, critical);
            Thread.sleep(2500);
        }
    }

    private static void performProgressInteraction(final Taskbar taskbar) throws InterruptedException
    {
        if (taskbar.isSupported(Feature.PROGRESS_VALUE))
        {
            for (int i = 0; i < 100; i++)
            {
                taskbar.setProgressValue(i);
                Thread.sleep(100);
            }
        }
    }
}