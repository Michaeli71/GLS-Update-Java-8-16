package exercises.part1.lambdadebug;

import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 *
 * @author Michael Inden
 *
 * Copyright 2017/2018 by Michael Inden
 */
public class LambdaDebug {

    public static void main(String[] args) {
        // Debugging
        Stream<String> names = Stream.of("Anne", "Peter", "John", "Mike", "Tim", "Mic", "Moni", "ABCDE");

        Predicate<String> strStartsWithM = str -> str.startsWith("M");
        Predicate<String> strLength4_ = str -> str.length() >= 4;
        Predicate<String> combi = strStartsWithM.or(strLength4_);

        names.
            peek(name -> System.out.println("Before: " +name)).
            filter(strStartsWithM).
            peek(name -> System.out.println("After M: " +name)).
            filter(str -> str.length() >= 4).
            peek(name -> System.out.println("After 4: " +name)).
            forEach(System.out::println);
    }
}
