package solutions.part1;

import static java.util.stream.Collectors.counting;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toSet;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class Exercise13_BONUS_FilteringCollectorJdk8Example 
{
	public static void main(final String[] args) 
	{
		final List<String> programming = List.of("Java", "JavaScript", "Groovy", "JavaFX", "Spring", "Java");
		
		final Stream<String> programmming1 = programming.stream();	
		final Set<String> result1 = programmming1.collect(Exercise13_BONUS_CollectorsUtils.filtering(name -> name.contains("Java"), toSet()));
		System.out.println(result1);
		
		final Stream<String> programmming2 = programming.stream();	
		final Map<String, Long> result2 = programmming2.collect(groupingBy(i -> i, 
				Exercise13_BONUS_CollectorsUtils.filtering(name -> name.contains("Java"), counting())));		
				
		System.out.println(result2);	

	}
}
