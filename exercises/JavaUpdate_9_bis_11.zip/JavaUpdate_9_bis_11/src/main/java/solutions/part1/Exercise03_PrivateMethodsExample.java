package solutions.part1;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public interface Exercise03_PrivateMethodsExample 
{
	public abstract int method();
	
    public default void calc1(float a, float b)
    {
        float sum = a + b;
        calcAvgAndPrint(sum);
    }
    
    public default void calc2(int a, int b)
    {
        int sum = a + b;
        calcAvgAndPrint(sum);
    }
    
    private void calcAvgAndPrint(float sum)
    {
        float avg = sum / 2;
        System.out.println("sum: " + sum + " / avg: " + avg);
    }
}