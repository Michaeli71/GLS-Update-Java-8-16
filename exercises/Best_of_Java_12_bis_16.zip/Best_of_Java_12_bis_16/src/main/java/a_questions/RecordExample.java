package a_questions;

/**
 * Beispielprogramm für den Workshop "Java 9 Hands On" / das Buch "Java 9 -- Die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2017/2018 by Michael Inden 
 */
public class RecordExample {

	public static void main(String[] args) {
		        
		MyPoint point = new MyPoint(17, 19);
		System.out.println("" + point.x() + ", " + point.y());	
	}
}
