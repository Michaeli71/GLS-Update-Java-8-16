package a_questions;

import java.util.ArrayList;

public class VarExample {

	public static void main(String[] args) {
		
		ArrayList<String> names = new ArrayList<>();
		names.add("Tim");
		//names.add(72);
		
		//List.of
	}

}
